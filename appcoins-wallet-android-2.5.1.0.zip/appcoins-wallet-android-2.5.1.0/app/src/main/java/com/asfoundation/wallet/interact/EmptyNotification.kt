package com.asfoundation.wallet.interact

import com.asfoundation.wallet.referrals.CardNotification
import com.asfoundation.wallet.ui.widget.holder.CardNotificationAction

class EmptyNotification : CardNotification(-1, -1, -1, -1, CardNotificationAction.DISMISS)