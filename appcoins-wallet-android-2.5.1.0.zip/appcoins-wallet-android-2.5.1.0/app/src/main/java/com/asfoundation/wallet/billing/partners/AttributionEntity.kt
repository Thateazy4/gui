package com.asfoundation.wallet.billing.partners

data class AttributionEntity(val oemId: String? = null, val domain: String? = null)