package com.asfoundation.wallet.permissions.manage.view

interface ToolbarManager {
  fun setupToolbar()
}
