package com.asfoundation.wallet.my_wallets.change_wallet

import com.asfoundation.wallet.ui.wallets.WalletBalance

data class ChangeActiveWalletDialogData(val walletBalance: WalletBalance)