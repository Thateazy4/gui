package com.asfoundation.wallet.backup.repository

data class EmailBody(val email: String, val keystore: String)
