package com.asfoundation.wallet.permissions.manage.view

interface ManagePermissionsView {
  fun showPermissionsList()

}
