package com.asfoundation.wallet.billing.share

data class GetPaymentLinkResponse(var url: String)
