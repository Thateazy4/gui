package com.asfoundation.wallet.backup.save_options

data class BackupSaveOptionsData(val walletAddress: String, val password: String)
