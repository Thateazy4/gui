package com.asfoundation.wallet.my_wallets.token

data class TokenInfoDialogData(
    val title: String,
    val image: String,
    val description: String,
    val showTopUp: Boolean
)