package com.asfoundation.wallet.promotions

enum class PromotionUpdateScreen {
  PROMOTIONS,
  TRANSACTIONS
}