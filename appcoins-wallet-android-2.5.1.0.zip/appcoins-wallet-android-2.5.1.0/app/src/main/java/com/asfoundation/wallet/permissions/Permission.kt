package com.asfoundation.wallet.permissions

data class Permission(val walletAddress: String, val permissionGranted: Boolean)