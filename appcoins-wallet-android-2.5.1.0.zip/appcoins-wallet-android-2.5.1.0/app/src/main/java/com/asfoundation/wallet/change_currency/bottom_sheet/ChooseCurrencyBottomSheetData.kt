package com.asfoundation.wallet.change_currency.bottom_sheet

data class ChooseCurrencyBottomSheetData(val flag: String, val currency: String,
                                         val label: String, val sign: String)
