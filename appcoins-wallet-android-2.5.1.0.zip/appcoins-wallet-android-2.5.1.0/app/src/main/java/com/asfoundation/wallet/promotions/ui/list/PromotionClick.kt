package com.asfoundation.wallet.promotions.ui.list

data class PromotionClick(
    val id: String,
    val extras: Map<String, String>? = null
)