package com.asfoundation.wallet.home.ui.list.transactions.empty

data class EmptyItem(
    val id: String,
    val animationRes: Int,
    val bodyText: String
)
