package com.asfoundation.wallet.backup.entry

data class BackupEntryData(val walletAddress: String)
