package com.asfoundation.wallet.permissions.request.view

interface CreateWalletNavigator {
  fun closeSuccess()
  fun closeCancel()
}
