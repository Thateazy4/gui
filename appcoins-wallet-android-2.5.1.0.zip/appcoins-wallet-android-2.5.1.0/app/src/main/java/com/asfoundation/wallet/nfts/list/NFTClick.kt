package com.asfoundation.wallet.nfts.list

import com.asfoundation.wallet.nfts.domain.NFTItem

data class NFTClick(val data: NFTItem)