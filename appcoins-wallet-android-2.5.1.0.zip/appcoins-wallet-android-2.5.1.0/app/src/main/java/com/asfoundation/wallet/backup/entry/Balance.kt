package com.asfoundation.wallet.backup.entry

data class Balance(val symbol: String, val amount: String)
