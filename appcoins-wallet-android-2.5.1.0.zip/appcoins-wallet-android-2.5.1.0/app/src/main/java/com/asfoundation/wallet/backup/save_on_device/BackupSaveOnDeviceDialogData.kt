package com.asfoundation.wallet.backup.save_on_device

data class BackupSaveOnDeviceDialogData(val walletAddress: String, val password: String)
