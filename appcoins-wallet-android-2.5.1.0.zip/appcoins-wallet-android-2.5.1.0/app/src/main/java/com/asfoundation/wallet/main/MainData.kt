package com.asfoundation.wallet.main

data class MainData(val fromSupportNotificationClick: Boolean)